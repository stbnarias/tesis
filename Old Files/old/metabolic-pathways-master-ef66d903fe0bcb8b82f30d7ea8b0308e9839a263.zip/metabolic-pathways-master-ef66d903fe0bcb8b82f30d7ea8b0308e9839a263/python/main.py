import json
import operator
from os import walk
import sys
import string
import pprint
from collections import OrderedDict

# KGML to JSON
from kgml2Json import SimpleKGML

# Graph
from graph import *

# Aligment Algorithms
from local_alignment import local_alignment
from global_alignment import needleman_wunsch
from semiglobal_alignment import semiglobal_alignment

level = -1
letter = 0
LOW = 0
FULL = 1
dictionary = {}
def add_to_dictionary(path):
    for node in path:
        if not node in dictionary:
            global letter, level
            if letter % 26 == 0:
                level = level + 1            
            dictionary[node] = string.ascii_uppercase[letter % 26] + str(level)
            letter = letter + 1

# return renamed path from dictIonary
def renamed_path(path):
    renamed = []
    for node in path:
        renamed.append(dictionary[node])
    return renamed

def show_dictionary():
    print "<p>" , "Dictionary", "</p>" 
    inv_dictionary = {v: k for k, v in dictionary.iteritems()}
    sorted_dict = sorted(inv_dictionary.items(), key=operator.itemgetter(0))
    for tuple in sorted_dict:
        print("<p class='dict-entry'>" + str(tuple[0]) + " -> " + str(tuple[1]) + "</p>")

def identify_equality(graph0, graph1, detail):
    equality = False
    for node in graph0.get_nodes():
        for edge in node.get_edges():
            value1 = node.get_value()
            value2 = edge.get_value()
            if value1 != '*':
                if graph1.exists_edge(str(value1), str(value2)):
                    equality = True
                    if detail:
                        print "<p class='indentify'>" + str(value1) + " -> " + str(value2) + "</p>"
                    else:
                        if value1 in dictionary and value2 in dictionary:
                            print "<p class='indentify'>" + str(dictionary[value1]) + " -> " + str(dictionary[value2]) + "</p>"
    if not equality:
        print "<p>None Found</p>"

def identify_differences(graph0, graph1, detail):
    differences = False
    for node in graph0.get_nodes():
        for edge in node.get_edges():
            value1 = node.get_value()
            value2 = edge.get_value()
            if value1 != '*':
                if not graph1.exists_edge(str(value1), str(value2)):
                    differences = True
                    if detail:
                        print "<p class='indentify'>" + str(value1) + " -> " + str(value2) + "</p>"
                    else:
                        if value1 in dictionary and value2 in dictionary:
                            print "<p class='indentify'>" + str(dictionary[value1]) + " -> " + str(dictionary[value2]) + "</p>"
    if not differences:
        print "<p>None Found</p>"                        

def metabolic_pathways_HTML(pathway0, pathway1):
    # graph creation
    graph0 = to_graph_from_dict(pathway0)
    graph1 = to_graph_from_dict(pathway1)
    bft0 = graph0.breadth_first_traversal()
    dft0 = graph0.depth_first_traversal() 
    add_to_dictionary(bft0)
    add_to_dictionary(dft0)
    bft1 = graph1.breadth_first_traversal()
    dft1 = graph1.depth_first_traversal()
    add_to_dictionary(bft1)
    add_to_dictionary(dft1)
    # Full Detail Output
    print "<h4>Full Detail Output</h4>"
    print "<p>Breadth First Traversal (BFT)</p>"
    print "<p class='pathway'>Pathway 1: ", ' '.join(bft0), "</p>"
    print "<p class='pathway'>Pathway 2: ", ' '.join(bft1), "</p>"
    print '<br>'
    print "<p>Depth First Traversal (DFT)</p>"
    print "<p class='pathway'>Pathway 1: ", ' '.join(dft0), "</p>"
    print "<p class='pathway'>Pathway 2: ", ' '.join(dft1), "</p>"
    print "<br>"
    show_dictionary()
    # Low Detail Output
    print "<h4>Low Detail Output</h4>"
    print "<p>Breadth First Search (BFT)</p>"
    print "<p class='pathway'>Pathway 1: ", ' '.join(renamed_path(bft0)), "</p>"
    print "<p class='pathway'>Pathway 2: ", ' '.join(renamed_path(bft1)), "</p>"
    print "<br>"
    print "<p>Depth First Search (DFT)</p>"
    print "<p class='pathway'>Pathway 1: ", ' '.join(renamed_path(dft0)), "</p>"
    print "<p class='pathway'>Pathway 2: ", ' '.join(renamed_path(dft1)), "</p>"
    print "<h4>Alignment Algorithms</h4>"
    print "<p>Global Alignment (BFT):</p>", '\n'.join(["<p class='alignment'>" + str(i) + "</p>" for i in needleman_wunsch(renamed_path(bft0), renamed_path(bft1))])
    print "<p>Global Alignment (DFT):</p>", '\n '.join(["<p class='alignment'>" + str(i) + "</p>" for i in needleman_wunsch(renamed_path(dft0), renamed_path(dft1))])
    print "<br>"
    print "<p>Local Alignment (BFT):</p>", '\n'.join(["<p class='alignment'>" + str(i) + "</p>" for i in local_alignment(renamed_path(bft0), renamed_path(bft1))])
    print "<p>Local Alignment (DFT):</p>", '\n'.join(["<p class='alignment'>" + str(i) + "</p>" for i in local_alignment(renamed_path(dft0), renamed_path(dft1))])
    print "<br>"
    print "<p>Semiglobal Alignment (BFT):</p>", '\n'.join(["<p class='alignment'>" + str(i) + "</p>" for i in semiglobal_alignment(renamed_path(bft0), renamed_path(bft1))])
    print "<p>Semiglobal Alignment (DFT):</p>", '\n'.join(["<p class='alignment'>" + str(i) + "</p>" for i in semiglobal_alignment(renamed_path(dft0), renamed_path(dft1))])
    print "<br>"
    print "<h4>Equality Identified</h4>"
    identify_equality(graph0, graph1, LOW)
    print "<br>"
    print "<h4>Differences Identified (from Pathway 1 to Pathway 2</h4>"
    identify_differences(graph0, graph1, FULL)
    print "<br>"
    print "<h4>Differences Identified (from Pathway 2 to Pathway 1</h4>"
    identify_differences(graph1, graph0, FULL)

if __name__ == '__main__':
    if len(sys.argv) > 1:
        filePath = sys.argv[1]
        myKGML = SimpleKGML(filePath)
        pathway0 = myKGML.getWithCentralNodeAsString()
        filePath = sys.argv[2]
        myKGML = SimpleKGML(filePath)
        pathway1 = myKGML.getWithCentralNodeAsString()
        metabolic_pathways_HTML(pathway0, pathway1)
    else:
        print("Incorrect number of parameters.")
        print("Expected: <path/KGML.xml>")